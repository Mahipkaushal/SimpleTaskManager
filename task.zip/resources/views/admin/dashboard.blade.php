@extends('admin.layout')

@section('content')
	
    <div class="col-xs-12 col-sm-10 col-sm-offset-1 wrapper"><h1>Dashboard</h1></div>

@endsection