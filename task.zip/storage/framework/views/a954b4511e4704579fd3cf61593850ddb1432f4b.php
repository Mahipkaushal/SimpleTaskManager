<div class="subtasks subtask-<?php echo e($subtask->id); ?>">
	<div class="subtask_title">		
		<?php echo e($subtask->title); ?>

	</div>
	<div class="subtask_description"><?php echo e($subtask->description); ?></div>
	<div class="subtask_date_added"><?php echo e(date('F d, Y h:i a', strtotime($subtask->created_at))); ?></div>
	<div class="subtask_actions">
		<div class="subtask_status">
			<ul>
				<li class="dropdown">
					<?php if($subtask->status != 3): ?>
						<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
							<?php if($subtask->status == 1): ?>
								<span class="status-tag active">Active <span class="caret"></span></span>
							<?php elseif($subtask->status == 2): ?>
								<span class="status-tag pending">Pending <span class="caret"></span></span>
							<?php endif; ?>
						</a>

						<ul class="dropdown-menu" role="menu">
		                	<li>
		                        <a class="subtask-status-action" data-sub-task-id="<?php echo e($subtask->id); ?>" data-status="1">
		                            Active
		                        </a>
		                    </li>
		                    <li>
		                        <a class="subtask-status-action" data-sub-task-id="<?php echo e($subtask->id); ?>" data-status="2">
		                            Pending
		                        </a>
		                    </li>
		                    <li>
		                        <a class="subtask-status-action" data-sub-task-id="<?php echo e($subtask->id); ?>" data-status="3">
		                            Completed
		                        </a>
		                    </li>
		                </ul>
	                <?php else: ?>
	                	<span class="status-tag completed">Completed</span>
	                <?php endif; ?>
				</li>
			</ul>
		</div>

		<div class="subtask_delete">
			<?php if(Auth::user()->role_id == 1 || Auth::user()->role_id == 3): ?>
			<a class="subtask-edit" data-sub-task-id="<?php echo e($subtask->id); ?>">
				<i class="fa fa-edit"></i>
			</a>
			<?php endif; ?>
			
			<?php if(Auth::user()->role_id == 1): ?>
			<a class="subtask-delete" data-sub-task-id="<?php echo e($subtask->id); ?>">
				<i class="fa fa-trash color-red"></i>
				<form style="display: none;">
                    <input type="hidden" name="id" value="<?php echo e($subtask->id); ?>">
                    <?php echo e(method_field('DELETE')); ?> 
                </form>
			</a>
			<?php endif; ?>
		</div>
	</div>
</div>