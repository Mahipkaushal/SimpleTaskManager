<footer class="col-xs-12 col-sm-12 footer text-center">
	<?php if(!Auth::guest()): ?>
	    <div class="container">
	    	<small class="credit">Designed and Developed by Mahip Kaushal</small>
	    	<br />
	        <small class="copyright">© <?php echo e(date('Y')); ?> Mahip Kaushal. All rights reserved.</small>
	    </div>
	<?php endif; ?>
</footer>

<?php if(Session::get('success')): ?>
    <script type="text/javascript">
        $(document).ready(function() {
            toastr.success('<?php echo e(Session::get('success')); ?>');
        });            
    </script>
<?php endif; ?>
<?php if(Session::get('errors')): ?>
    <script type="text/javascript">
        $(document).ready(function() {
            <?php $__currentLoopData = Session::get('errors'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                toastr.error('<?php echo e($error); ?>');
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        });
    </script>
<?php endif; ?>