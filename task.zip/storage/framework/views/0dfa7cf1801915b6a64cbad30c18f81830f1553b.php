<?php $__env->startSection('content'); ?>
	<div class="col-sm-12">
        <div class="col-xs-12 col-sm-6 col-sm-offset-3 wrapper">        
            <form id="setting_form" action="<?php echo e(route('setting')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>           
            	<div class="row form-group">
            		<div class="col-sm-12">
        				<div class="col-sm-4">Name:</div>
                        <div class="col-sm-8">
                            <input type="text" name="name" class="form-control" value="<?php echo e(Auth::user()->name); ?>">
                        </div>
        			</div>
            	</div>
                <div class="row form-group">
                    <div class="col-sm-12">
                        <div class="col-sm-4">Username:</div>
                        <div class="col-sm-8">
                            <input type="text" disabled="disabled" class="form-control" value="<?php echo e(Auth::user()->username); ?>">
                        </div>
                    </div>
                </div>
                <div class="row form-group">
                    <div class="col-sm-12">
                        <div class="col-sm-4">Email:</div>
                        <div class="col-sm-8">
                            <input type="text" name="email" class="form-control" value="<?php echo e(Auth::user()->email); ?>">
                        </div>
                    </div>
                </div>
                <div class="row form-group">
                    <div class="col-sm-12">
                        <div class="col-sm-4">Role:</div>
                        <div class="col-sm-8">
                            <select class="form-control" disabled="disabled">
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($role->id == Auth::user()->role_id): ?>
                                        <option value="<?php echo e($role->id); ?>" selected="selected"><?php echo e($role->name); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row form-group">
                    <div class="col-sm-12">
                        <div class="col-sm-4">Password:</div>
                        <div class="col-sm-8">
                            <input type="text" name="password" class="form-control" value="">
                        </div>
                    </div>
                </div>
                <div class="row form-group">
                    <div class="col-sm-12" style="text-align: right; padding-right: 30px;">
                        <a class="btn btn-setting-save" onclick="$('#setting_form').submit();"><i class="fa fa-save"></i> Save</a>
                    </div>
                </div>
            </form>
        </div>
    </div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>