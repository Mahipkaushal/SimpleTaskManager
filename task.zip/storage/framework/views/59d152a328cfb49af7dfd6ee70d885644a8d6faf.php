<?php $__env->startSection('content'); ?>
	
    <div class="col-xs-12 col-sm-10 col-sm-offset-1 wrapper"><h1>Dashboard</h1></div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>