<?php $__env->startSection('content'); ?>
	
    <div class="col-xs-12 col-sm-10 col-sm-offset-1 wrapper">
    	<div class="row task-list"></div>

        <a class="btn btn-add_new_task_form" href="#add_new_task_form" role="button" data-toggle="modal" title="Create New Task"><i class="fa fa-plus" aria-hidden="true"></i></a>
    </div>

    <div class="col-xs-12 col-sm-6 col-md-4 sub-task-wrapper">
        <div class="wrapper-header">
            <button type="button" class="close" aria-hidden="true">&times;</button>
        </div>
        <div class="wrapper-body">
            <div class="sub-task-list"></div>
        </div>
        <div class="wrapper-footer"></div>
    </div>

    <script type="text/javascript">
    	$(document).ready(function() {
    		getTasks('/tasks');
    	});
    </script>

    <?php echo $__env->make('forms.add_new_task', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('forms.update_task', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('forms.delete_task', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('forms.add_new_sub_task', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('forms.update_sub_task', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>