<form>
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="id" value="<?php echo e($subtask->id); ?>" />
    <input type="hidden" name="task_id" value="<?php echo e($subtask->task_id); ?>" />
    <input type="hidden" name="status" value="<?php echo e($subtask->status); ?>" />
    <div class="row form-group">
        <div class="col-sm-12">
            <div class="col-sm-3">
                <span>Title:</span>
            </div>
            <div class="col-sm-9">
                <input type="text" name="title" class="form-control" value="<?php echo e($subtask->title); ?>" />
            </div>
        </div>
    </div>
    <div class="row form-group">
        <div class="col-sm-12">
            <div class="col-sm-3">
                <span>Description:</span>
            </div>
            <div class="col-sm-9">
                <input type="text" name="description" class="form-control" value="<?php echo e($subtask->description); ?>" />
            </div>
        </div>
    </div>    
</form>