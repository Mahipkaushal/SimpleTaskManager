<?php $__env->startSection('content'); ?>    
	<div class="col-sm-12">
        <div class="col-xs-12 col-sm-12 wrapper">
            <div class="col-sm-12">
                <table class="table">
                    <thead>
                        <tr>
                            <th>User ID</th>
                            <th>Name</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Date Added</th>
                            <th>Date Updated</th>                            
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($users): ?>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($user->id); ?></th>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->username); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->role['name']); ?></td>
                                    <td><?php echo e(date('F d, Y h:i a', strtotime($user->created_at))); ?></td>
                                    <td><?php echo e(date('F d, Y h:i a', strtotime($user->updated_at))); ?></td>
                                    <td>
                                        <?php if($user->id == Auth::user()->id): ?>
                                        <a class="actions" href="<?php echo e(route('setting')); ?>" target="_blank"><i class="fa fa-eye" title="View"></i></a>
                                        <?php else: ?>
                                        <a class="actions user_edit" data-user-id="<?php echo e($user->id); ?>" href="#update_user_form" role="button" data-toggle="modal"><i class="fa fa-edit" title="Edit User"></i></a>                                        
                                        <a class="actions user_delete color-red" data-user-id="<?php echo e($user->id); ?>" href="#delete_user_form" role="button" data-toggle="modal"><i class="fa fa-trash" title="Delete User"></i></a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="9">No user found!</td>
                            </tr>
                        <?php endif; ?>          
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="9"><?php echo e($users->links()); ?></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>

        <a class="btn btn-add_new_user_form pull-right" href="#add_new_user_form" role="button" data-toggle="modal" title="Create New User"><i class="fa fa-plus" aria-hidden="true"></i></a>
        
    </div>

    <?php echo $__env->make('forms.add_new_user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('forms.update_user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('forms.delete_user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>