<div class="col-sm-12">
	<?php if(!empty($subtasks)): ?>
		<?php $__currentLoopData = $subtasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subtask): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php echo $__env->make('subtask', ['subtask' => $subtask], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php else: ?>
		<div class="no_result">
			No Sub Task created yet!
		</div>
	<?php endif; ?>
</div>