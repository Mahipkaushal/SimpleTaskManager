<tr>
	<th scope="row"><?php echo e($task->id); ?></th>
	<td><?php echo e($task->title); ?></td>
	<td><?php echo e($task->description); ?></td>
	<td><?php echo e($task->user['name']); ?></td>
	<td><?php echo e(date('F d, Y h:i a', strtotime($task->created_at))); ?></td>
	<td><?php echo e(date('F d, Y h:i a', strtotime($task->updated_at))); ?></td>
	<td>
		<ul>
			<li class="dropdown">
				<?php if($task->status != 3): ?>
					<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
						<?php if($task->status == 1): ?>
							<span class="status-tag active">Active <span class="caret"></span></span>
						<?php elseif($task->status == 2): ?>
							<span class="status-tag pending">Pending <span class="caret"></span></span>
						<?php endif; ?>
					</a>

					<ul class="dropdown-menu" role="menu">
		            	<li>
		                    <a class="task-status-action" data-task-id="<?php echo e($task->id); ?>" data-status="1">
		                        Active
		                    </a>
		                </li>
		                <li>
		                    <a class="task-status-action" data-task-id="<?php echo e($task->id); ?>" data-status="2">
		                        Pending
		                    </a>
		                </li>
		                <li>
		                    <a class="task-status-action" data-task-id="<?php echo e($task->id); ?>" data-status="3">
		                        Completed
		                    </a>
		                </li>
		            </ul>
		        <?php else: ?>
		        	<span class="status-tag completed">Completed</span>
	            <?php endif; ?>
			</li>
		</ul>									
	</td>
	<td>
		<a class="actions task_view" data-task-id="<?php echo e($task->id); ?>"><i class="fa fa-eye" title="View"></i></a>
		<?php if(Auth::user()->role_id == 1 || Auth::user()->role_id == 3): ?>
		<a class="actions task_edit" data-task-id="<?php echo e($task->id); ?>" href="#update_task_form" role="button" data-toggle="modal"><i class="fa fa-edit" title="Edit Task"></i></a>
		<?php endif; ?>
		<?php if(Auth::user()->role_id == 1): ?>
		<a class="actions task_delete color-red" data-task-id="<?php echo e($task->id); ?>" href="#delete_task_form" role="button" data-toggle="modal"><i class="fa fa-trash" title="Delete Task"></i></a>
		<?php endif; ?>
	</td>
</tr>