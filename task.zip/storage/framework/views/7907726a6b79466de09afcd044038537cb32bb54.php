<form>
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="id" value="<?php echo e($user->id); ?>" />
    <div class="row form-group">
        <div class="col-sm-12">
            <div class="col-sm-3">
                <span>Name:</span>
            </div>
            <div class="col-sm-9">
                <input type="text" name="name" class="form-control" value="<?php echo e($user->name); ?>" />
            </div>
        </div>
    </div>
    <div class="row form-group">
        <div class="col-sm-12">
            <div class="col-sm-3">
                <span>Email:</span>
            </div>
            <div class="col-sm-9">
                <input type="text" name="email" class="form-control" value="<?php echo e($user->email); ?>" />
            </div>
        </div>
    </div>
    <div class="row form-group">
        <div class="col-sm-12">
            <div class="col-sm-3">
                <span>Role:</span>
            </div>
            <div class="col-sm-9">
                <select class="form-control" name="role_id">
                    <?php if($roles): ?>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($role->id == $user->role_id): ?>
                                <option value="<?php echo e($role->id); ?>" selected="selected"><?php echo e($role->name); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <option value="0"></option>
                    <?php endif; ?>
                </select>
            </div>
        </div>
    </div>
</form>