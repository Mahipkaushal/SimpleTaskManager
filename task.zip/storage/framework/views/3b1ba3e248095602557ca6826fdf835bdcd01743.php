<div class="col-sm-12">
	<table class="table">
		<thead>
			<tr>
				<th>Task ID</th>
				<th>Title</th>
				<th>Description</th>
				<th>Created By</th>						
				<th>Date Added</th>
				<th>Date Updated</th>
				<th>Status</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<?php if($tasks): ?>
				<?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php echo $__env->make('task', ['task' => $task], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php else: ?>
				<tr>
					<td colspan="8">No task found!</td>
				</tr>
			<?php endif; ?>			
		</tbody>
		<tfoot>
			<tr>
				<td colspan="8"><?php echo e($tasks->links()); ?></td>
			</tr>
		</tfoot>
	</table>
</div>