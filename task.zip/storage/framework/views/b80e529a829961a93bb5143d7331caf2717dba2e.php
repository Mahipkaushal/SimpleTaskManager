<header class="navbar navbar-default header">
    <div class="container">
    	<?php if(!Auth::guest()): ?>
	        <div class="navbar-header">
	        	<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
	                <span class="sr-only">Toggle Navigation</span>
	                <span class="icon-bar"></span>
	                <span class="icon-bar"></span>
	                <span class="icon-bar"></span>
	            </button>

	            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
	                <?php echo e(config('app.name', 'Task Manager')); ?>

	            </a>
	        </div>

	        <div class="collapse navbar-collapse" id="app-navbar-collapse">
	            <ul class="nav navbar-nav">
	            	<li>
	            		<a href="<?php echo e(route('home')); ?>"><i class="fa fa-home"></i> Home</a>
	            	</li>
	            	<?php if(Auth::user()->role_id == 1): ?>
	            	<li>
	            		<a href="<?php echo e(route('users')); ?>"><i class="fa fa-user"></i> Users</a>
	            	</li>
	            	<?php endif; ?>
	            </ul>

	            <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                            Hi <?php echo e(Auth::user()->name); ?>! <span class="caret"></span>
                        </a>

                        <ul class="dropdown-menu" role="menu">
                        	<li>
                                <a href="<?php echo e(route('setting')); ?>">
                                    Setting
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('logout')); ?>" >
                                    Logout
                                </a>
                            </li>
                        </ul>
                    </li>
	            </ul>
	        </div>
	    <?php else: ?>
	    	<div class="navbar-header">
	            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
	                <?php echo e(config('app.name', 'Task Manager')); ?>

	            </a>
	        </div>
        <?php endif; ?>
    </div>
</header>